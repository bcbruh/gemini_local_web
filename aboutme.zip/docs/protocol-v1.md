# Local agent protocol V1

`local-agent/v1` is the strict response contract between a brain response and the local agent runtime. The runtime, not the model, validates and executes tools.

Exactly one JSON object is accepted per brain turn. Markdown fences, surrounding prose, duplicate properties and unknown properties are rejected.

## Final response

```json
{
  "protocol": "local-agent/v1",
  "type": "final",
  "message": "Answer for the user"
}
```

## Tool request

```json
{
  "protocol": "local-agent/v1",
  "type": "tool_request",
  "request_id": "unique-within-the-run",
  "tool": "read_file",
  "arguments": {
    "path": "src/App.cs",
    "start_line": 1,
    "end_line": 200
  }
}
```

V1 permits one tool request per turn. `arguments` must be an object and the requested tool must exist in the runtime registry. A parse or validation failure never creates a tool action; the orchestrator may request a corrected response within its retry budget.

The complete envelope is limited to 64 KiB. Tool-specific schemas impose tighter bounds where appropriate.

## Tool observation

The local runtime, never the brain, creates tool observations. Every observation repeats the exact `request_id` and is sent back using the `TOOL` role.

```json
{
  "protocol": "local-agent/v1",
  "type": "tool_result",
  "request_id": "unique-within-the-run",
  "tool": "read_file",
  "status": "succeeded",
  "output": {}
}
```

Failed calls use `status: "failed"` and a typed, sanitized `error`. Observations are size-bounded before entering model context. Repeated request IDs are rejected and never execute a tool twice.
